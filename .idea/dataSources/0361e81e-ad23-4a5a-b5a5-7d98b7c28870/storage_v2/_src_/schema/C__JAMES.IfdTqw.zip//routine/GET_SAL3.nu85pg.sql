create procedure get_sal3(dept_id number,v_sum_sal out number)

is
   cursor  salary_cursor is select EMPLOYEES.SALARY from EMPLOYEES where DEPARTMENT_ID = dept_id;
begin
   v_sum_sal :=0;
   for c in salary_cursor loop
     v_sum_sal := v_sum_sal +c.SALARY;
     -- DBMS_OUTPUT.PUT_LINE(c.SALARY);
  end loop;
    --select sum(SALARY) into v_sum_sal from EMPLOYEES where DEPARTMENT_ID = dept_id;
end;
/

