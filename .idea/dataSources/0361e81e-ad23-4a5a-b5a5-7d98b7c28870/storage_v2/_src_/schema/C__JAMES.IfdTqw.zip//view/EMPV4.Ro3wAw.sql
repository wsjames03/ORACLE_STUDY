create view EMPV4 as
select d.DEPARTMENT_NAME,avg(salary) AS avg_sal from EMPLOYEES e,DEPARTMENTS d where e.DEPARTMENT_ID = d.DEPARTMENT_ID
group by DEPARTMENT_NAME
/

