create view EMPV3 as
select EMPLOYEE_ID id,LAST_NAME name ,salary,DEPARTMENT_NAME
from EMPLOYEES e,DEPARTMENTS d where e.EMPLOYEE_ID=d.DEPARTMENT_ID
    with read only
/

